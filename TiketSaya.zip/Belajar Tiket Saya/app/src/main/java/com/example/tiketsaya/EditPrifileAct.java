package com.example.tiketsaya;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class EditPrifileAct extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_prifile);
    }
}
